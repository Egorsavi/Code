#include <stdio.h>
#include "math.h"

int main() {
    float r, h;
    printf("Enter a r:");
    scanf("%f", &r);
    printf("Enter h:");
    scanf("%f", &h);
    float s, v;
    s = 2*M_PI*r*h;
    v = pow(r, 2)*h*M_PI;
    printf("S = %f\nV = %f", s, v);
    return 0;
}